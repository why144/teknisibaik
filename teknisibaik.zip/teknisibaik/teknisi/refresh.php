<?php 
header("Refresh:0; url=dashboard.php");

 ?>