<?php 
header("Refresh:0; url=history.php");

 ?>